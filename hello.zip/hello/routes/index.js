var express = require('express');
var router = express.Router();


var connection = require('./conn');
connection.connect(() => {
  console.log("数据库连接成功...")
})
/* GET home page. */
router.post('/checklogin', (req, res) =>  {
  let {phonenum,passw} = req.body;
  console.log(phonenum,passw);
  const sqlStr0 = 'select * from users where phonenum = ? and passw = ?';
  connection.query(sqlStr0,[phonenum,passw],(err,data) => {
    if(err){
      throw err;
    }else{
      res.set('Content-Type','text/html');
      res.send(data)
    }
  })
});

router.post('/checkregist', (req, res) =>  {
  let {idnum} = req.body;
  const sqlStr30 = 'select * from users where idnum = ?';
  connection.query(sqlStr30,[idnum],(err,data) => {
    if(err){
      throw err;
    }else{
      res.set('Content-Type','text/html');
      res.send(data)
    }
  })
});

router.post('/register',(req,res) => {
  let {phonenum,sex,age,realname,idnum,passw} = req.body;
  console.log(phonenum,sex,age,realname,idnum,passw);
  const sqlStr1 = 'insert into users(phonenum,sex,age,realname,idnum,passw) values (?,?,?,?,?,?)';
  connection.query(sqlStr1,[phonenum,sex,age,realname,idnum,passw],(err,data) => {
    if(err){
      throw err;
    }else{
     // res.set('Content-Type','text/html');
     // res.send(data)
     res.send("注册成功");
     console.log(data);
    }
  })
})

router.post('/selectDepart',(req,res) => {
  const sqlStr2 = 'select * from depart'
  connection.query(sqlStr2,(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
    }
  })
})

router.post('/selectDoctor',(req,res) => {
  const sqlStr3 = 'select * from doctors'
  connection.query(sqlStr3,(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
    }
  })
})

router.post('/insertReg',(req,res) => {
  let{depart,dname,date1,time,realname,age,phonenum} = req.body;
  const sqlStr4 = 'insert into registerform(depart,dname,date1,time,realname,age,phonenum) values(?,?,?,?,?,?,?)';
  connection.query(sqlStr4,[depart,dname,date1,time,realname,age,phonenum],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send("预约成功");
      console.log(data);
    }
  })
})

router.post('/selectRegisterform',(req,res) => {
  const sqlStr5 = "select realname,dname,depart,date1,time,age,phonenum,(case state when '0' then '审核中' when '1' then '已同意' else '已拒绝' end)as state from registerform GROUP by date1 desc,id desc"
  connection.query(sqlStr5,(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
    }
  })
})

router.post('/update1',(req,res) => {
  let {phonenum} = req.body;
  console.log(phonenum);
  const sqlStr6 ="UPDATE registerform SET state ='1' WHERE phonenum = ?";
  connection.query(sqlStr6,[phonenum],(err,data) => {
    if(err){
      throw err;
    }else{
     // res.set('Content-Type','text/html');
     // res.send(data)
     res.send("已同意预约");
     console.log(data);
    }
  })
})

router.post('/update2',(req,res) => {
  let {phonenum} = req.body;
  console.log(phonenum);
  const sqlStr7 ="UPDATE registerform SET state ='2' WHERE phonenum = ?";
  connection.query(sqlStr7,[phonenum],(err,data) => {
    if(err){
      throw err;
    }else{
     // res.set('Content-Type','text/html');
     // res.send(data)
     res.send("已拒绝预约");
     console.log(data);
    }
  })
})

router.post('/addDoctors',(req,res) => {
  let{dname,dsex,duty,speciacism,depart,intro} = req.body;
  const sqlStr8 = 'insert into doctors(dname,dsex,duty,speciacism,depart,intro) values(?,?,?,?,?,?)';
  connection.query(sqlStr8,[dname,dsex,duty,speciacism,depart,intro],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send("增添成功");
      console.log(data);
    }
  })
})

router.post('/addDepartment',(req,res) => {
  let{dename,explainText} = req.body;
  const sqlStr9 = 'insert into depart(dename,explainText) values(?,?)';
  connection.query(sqlStr9,[dename,explainText],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send("增添成功");
    }
  })
})

router.post('/addNotice',(req,res) => {
  let{title,explainText,date} = req.body;
  const sqlStr13 = 'insert into notice(title,explainText,date) values(?,?,?)';
  connection.query(sqlStr13,[title,explainText,date],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send("增添成功");
    }
  })
})

router.post('/selectPersonal',(req,res) => {
  let {phonenow} = req.body;
  const sqlStr10 = "select realname,dname,depart,date1,time,age,phonenum,(case state when '0' then '审核中' when '1' then '已同意' else '已拒绝' end)as state from registerform WHERE realname = ? GROUP by date1 desc,id desc"
  connection.query(sqlStr10,[phonenow],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
      console.log(data);
    }
  })
})

router.post('/selectDoctornow',(req,res) => {
  let {depart} =req.body;
  const sqlStr11 = 'select * from doctors WHERE depart = ?'
  connection.query(sqlStr11,[depart],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
    }
  })
})

router.post('/adminLogin',(req,res) => {
  let {aname,apassw} = req.body;
  const sqlStr12 = 'select * from admin WHERE aname = ? and apassw = ?'
  connection.query(sqlStr12,[aname,apassw],(err,data) => {
    if(err){
      throw err;
    }else{
      res.set('Content-Type','text/html');
      res.send(data)
    }
  }) 
})

router.post('/selectNotice',(req,res) => {
  const sqlStr15 = 'select * from notice GROUP by date desc,id desc'
  connection.query(sqlStr15,(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
    }
  })
})

router.post('/selectfromnow',(req,res) => {
  let {depart} =req.body;
  const sqlStr16 = "select realname,dname,depart,date1,time,age,phonenum,(case state when '0' then '审核中' when '1' then '已同意' else '已拒绝' end)as state from registerform  WHERE depart = ? GROUP by date1 desc,id desc"
  connection.query(sqlStr16,[depart],(err,data) => {
    if(err){
      throw err;
    }else{
      res.send(data)
    }
  })
})
module.exports = router;
